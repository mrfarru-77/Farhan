import { useState } from 'react';
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";

const songs = [
  { title: "Tum Hi Ho", category: "Bollywood", url: "/songs/tum_hi_ho.mp3" },
  { title: "Mixtape Party", category: "Remix", url: "/songs/mixtape_party.mp3" },
  { title: "Tujhe Bhula Diya", category: "Sad", url: "/songs/tujhe_bhula_diya.mp3" }
];

export default function TrackFarruApp() {
  const [filter, setFilter] = useState("All");
  const filteredSongs = filter === "All" ? songs : songs.filter(song => song.category === filter);

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-4">TRACK FARRU</h1>
      <p className="text-center text-muted-foreground mb-6">Hindi | English Songs</p>
      <Tabs defaultValue="All" onValueChange={setFilter} className="mb-6">
        <TabsList>
          <TabsTrigger value="All">All</TabsTrigger>
          <TabsTrigger value="Bollywood">Bollywood</TabsTrigger>
          <TabsTrigger value="Remix">Remix</TabsTrigger>
          <TabsTrigger value="Sad">Sad Songs</TabsTrigger>
        </TabsList>
      </Tabs>
      <div className="grid gap-4 md:grid-cols-2">
        {filteredSongs.map((song, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold mb-2">{song.title}</h2>
              <audio controls className="w-full mb-2">
                <source src={song.url} type="audio/mpeg" />
              </audio>
              <Button variant="outline" asChild>
                <a href={song.url} download>डाउनलोड / Download</a>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
